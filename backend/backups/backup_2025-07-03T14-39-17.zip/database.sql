-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: conflict_checker
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `entity_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,5,'Axmatov Davranbek','case.create','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"clientInn\": \"207249779\", \"caseNumber\": \"5\", \"clientName\": \"ooo praelegal\", \"opponentInn\": \"207341301\", \"opponentName\": \"ooo praelegal consultancy\", \"conflictLevel\": \"none\", \"lawyerAssigned\": 5}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-02 12:39:10'),(2,5,'Axmatov Davranbek','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"ооо антитест\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 2}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-02 13:02:26'),(3,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-02 13:08:40'),(4,1,'System Administrator','user.login','user',1,'admin','{\"role\": \"admin\", \"loginTime\": \"2025-07-02T13:33:04.650Z\"}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 13:33:04'),(5,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"Ooo praelegal consultancy\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 13:33:54'),(6,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 13:33:57'),(7,1,'System Administrator','conflict.check','case',6,'ooo praelegal','{\"caseNumber\": \"5\", \"clientName\": \"ooo praelegal\", \"conflictLevel\": \"none\", \"conflictReason\": \"\", \"conflictingCases\": []}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 13:34:11'),(8,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 13:34:11'),(9,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-02 13:52:03'),(10,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.242','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/137.0.7151.107 Mobile/15E148 Safari/604.1','2025-07-02 14:06:45'),(11,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-02 14:23:50'),(12,1,'System Administrator','user.create','user',7,'Ismatov Jahongir','{\"role\": \"user\", \"email\": \"j.ismatov@praelegal.uz\", \"username\": \"Jahongir\", \"permissions\": {\"edit\": false, \"create\": true, \"delete\": false, \"manageUsers\": false}}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 08:56:41'),(13,7,'Ismatov Jahongir','user.login','user',7,'Jahongir','{\"role\": \"user\", \"loginTime\": \"2025-07-03T08:57:14.179Z\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 08:57:14'),(14,7,'Ismatov Jahongir','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"ooo antitest\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 2}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 08:57:33'),(15,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:17:52'),(16,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"error\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:17:59'),(17,1,'System Administrator','case.view','case',2,'Зкфу','{\"caseType\": \"contract\", \"caseNumber\": \"2\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:18:32'),(18,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"333777000\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"error\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:18:38'),(19,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:21:56'),(20,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:22:01'),(21,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"207341301\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:22:08'),(22,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"207341301\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:22:11'),(23,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:26:09'),(24,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"207341301\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:26:31'),(25,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:26:35'),(26,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:26:37'),(27,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207249779\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:26:43'),(28,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:29:39'),(29,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"ооо праелегал консультанси\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:30:05'),(30,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": \"ooo praelegal consultancy\", \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:30:15'),(31,1,'System Administrator','case.view','case',2,'Зкфу','{\"caseType\": \"contract\", \"caseNumber\": \"2\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:32:42'),(32,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"12345678901234\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:32:52'),(33,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"12345678901234\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:33:02'),(34,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"12345678901234\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:33:03'),(35,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"12345678901234\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:33:03'),(36,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"12345678901234\", \"opponentName\": null, \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 09:33:03'),(37,1,'System Administrator','backup.create','backup',NULL,'backup_2025-07-03T10-17-48.zip','{\"size\": 3769707, \"type\": \"manual\", \"filename\": \"backup_2025-07-03T10-17-48.zip\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 10:17:50'),(38,1,'System Administrator','user.login','user',1,'admin','{\"role\": \"admin\", \"loginTime\": \"2025-07-03T10:19:35.371Z\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 10:19:35'),(39,6,'Kim Irina','user.login','user',6,'Irina','{\"role\": \"user\", \"loginTime\": \"2025-07-03T11:26:15.724Z\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 11:26:15'),(40,7,'Ismatov Jahongir','user.login','user',7,'Jahongir','{\"role\": \"user\", \"loginTime\": \"2025-07-03T11:36:10.076Z\"}','192.168.1.211','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2025-07-03 11:36:10'),(41,7,'Ismatov Jahongir','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": \"207341301\", \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.211','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2025-07-03 11:36:40'),(42,1,'System Administrator','user.update','user',7,'Ismatov Jahongir','{\"changes\": {\"isActive\": false}, \"updatedFields\": [\"isActive\"]}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 11:39:15'),(43,1,'System Administrator','user.update','user',7,'Ismatov Jahongir','{\"changes\": {\"isActive\": true}, \"updatedFields\": [\"isActive\"]}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 11:39:23'),(44,7,'Ismatov Jahongir','user.login','user',7,'Jahongir','{\"role\": \"user\", \"loginTime\": \"2025-07-03T11:39:32.506Z\"}','192.168.1.211','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2025-07-03 11:39:32'),(45,1,'System Administrator','case.view','case',2,'Зкфу','{\"caseType\": \"contract\", \"caseNumber\": \"2\"}','192.168.1.51','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 11:40:35'),(46,1,'System Administrator','user.login','user',1,'admin','{\"role\": \"admin\", \"loginTime\": \"2025-07-03T12:10:05.994Z\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:05'),(47,1,'System Administrator','case.view','case',6,'ooo praelegal','{\"caseType\": \"litigation\", \"caseNumber\": \"5\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:11'),(48,1,'System Administrator','case.delete','case',6,'ooo praelegal','{\"caseNumber\": \"5\", \"clientName\": \"ooo praelegal\", \"documentCount\": 0}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:13'),(49,1,'System Administrator','case.view','case',4,'ООО ТЕСТ','{\"caseType\": \"litigation\", \"caseNumber\": \"3\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:15'),(50,1,'System Administrator','case.delete','case',4,'ООО ТЕСТ','{\"caseNumber\": \"3\", \"clientName\": \"ООО ТЕСТ\", \"documentCount\": 0}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:17'),(51,1,'System Administrator','case.view','case',3,'ООО ТЕСТ','{\"caseType\": \"litigation\", \"caseNumber\": \"1\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:18'),(52,1,'System Administrator','case.delete','case',3,'ООО ТЕСТ','{\"caseNumber\": \"1\", \"clientName\": \"ООО ТЕСТ\", \"documentCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:20'),(53,1,'System Administrator','case.view','case',2,'Зкфу','{\"caseType\": \"contract\", \"caseNumber\": \"2\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:21'),(54,1,'System Administrator','case.delete','case',2,'Зкфу','{\"caseNumber\": \"2\", \"clientName\": \"Зкфу\", \"documentCount\": 2}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:10:23'),(55,1,'System Administrator','case.create','case',7,'ООО «ART MEBEL STYLE','{\"caseType\": \"litigation\", \"clientInn\": \"304365452\", \"caseNumber\": \"44/2025-ХС\", \"clientName\": \"ООО «ART MEBEL STYLE\", \"opponentInn\": null, \"opponentName\": \"АТБ «Бизнесни ривожлантириш банки»\", \"conflictLevel\": \"none\", \"lawyersAssigned\": []}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:11:55'),(56,1,'System Administrator','case.view','case',7,'ООО «ART MEBEL STYLE','{\"caseType\": \"litigation\", \"caseNumber\": \"44/2025-ХС\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:12:05'),(57,1,'System Administrator','document.upload','document',12,'Договор_юр_помощь_07.07.2025.pdf','{\"caseId\": \"7\", \"caseName\": \"ООО «ART MEBEL STYLE\", \"fileName\": \"Договор_юр_помощь_07.07.2025.pdf\", \"fileSize\": 181622, \"mimeType\": \"application/pdf\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:12:13'),(58,1,'System Administrator','case.view','case',7,'ООО «ART MEBEL STYLE','{\"caseType\": \"litigation\", \"caseNumber\": \"44/2025-ХС\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:12:13'),(59,1,'System Administrator','case.create','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"clientInn\": null, \"caseNumber\": \"49/2025-Х\", \"clientName\": \"ООО «AGIO HEALTHCARE INTERNATIONAL»\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"lawyersAssigned\": []}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:15:51'),(60,1,'System Administrator','case.view','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"caseNumber\": \"49/2025-Х\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:15:53'),(61,1,'System Administrator','document.upload','document',13,'Договор разовый_Amrita pharm 25062025.pdf','{\"caseId\": \"8\", \"caseName\": \"ООО «AGIO HEALTHCARE INTERNATIONAL»\", \"fileName\": \"Договор разовый_Amrita pharm 25062025.pdf\", \"fileSize\": 161922, \"mimeType\": \"application/pdf\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:16:04'),(62,1,'System Administrator','case.view','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"caseNumber\": \"49/2025-Х\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:16:04'),(63,1,'System Administrator','case.view','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"caseNumber\": \"49/2025-Х\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:23:11'),(64,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО «AGIO HEALTHCARE INTERNATIONAL»\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:23:57'),(65,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:04'),(66,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:05'),(67,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:05'),(68,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:06'),(69,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"none\", \"conflictingCaseCount\": 0}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:10'),(70,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО AGIO HEALTHCARE INTERNATIONAL\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:24:15'),(71,1,'System Administrator','backup.delete','backup',NULL,'backup_2025-07-03T10-17-48.zip','{\"filename\": \"backup_2025-07-03T10-17-48.zip\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:32:13'),(72,1,'System Administrator','backup.create','backup',NULL,'backup_2025-07-03T12-32-17.zip','{\"size\": 322941, \"type\": \"manual\", \"filename\": \"backup_2025-07-03T12-32-17.zip\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:32:17'),(73,1,'System Administrator','case.view','case',7,'ООО «ART MEBEL STYLE','{\"caseType\": \"litigation\", \"caseNumber\": \"44/2025-ХС\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:55:01'),(74,1,'System Administrator','case.update','case',7,'ООО «ART MEBEL STYLE','{\"changes\": {\"founders\": [], \"case_type\": \"litigation\", \"directors\": [{\"name\": \"UMAROV ABDULAHAD RAXMATJON O`G`LI\", \"pinfl\": \"\"}], \"client_inn\": \"304365452\", \"client_name\": \"ООО «ART MEBEL STYLE»\", \"description\": \"❖ Дача консультаций и разъяснений по правовым вопросам касательно договора № 4243511.1.1\\nот 26.02.2025 года, заключенный между Доверителем и АТБ «Бизнесни ривожлантириш банки»;\\n❖ Представление и защита прав и законных интересов Доверителя в судебном заседании,\\nназначенном на 7 июля 2025 года, по экономическому делу № 4-1001-2504/65467 по исковому\\nзаявлению АТБ «Бизнесни ривожлантириш банки» к Доверителю.\", \"opponent_inn\": \"\", \"beneficiaries\": [], \"opponent_name\": \"АТБ «Бизнесни ривожлантириш банки»\", \"lawyersAssigned\": [], \"related_companies\": []}, \"updatedFields\": [\"client_name\", \"client_inn\", \"opponent_name\", \"opponent_inn\", \"case_type\", \"description\", \"lawyersAssigned\", \"related_companies\", \"founders\", \"directors\", \"beneficiaries\"]}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:55:41'),(75,1,'System Administrator','case.view','case',7,'ООО «ART MEBEL STYLE»','{\"caseType\": \"litigation\", \"caseNumber\": \"44/2025-ХС\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 12:55:41'),(76,1,'System Administrator','user.update','user',7,'Ismatov Jahongir','{\"changes\": {\"isActive\": false}, \"updatedFields\": [\"isActive\"]}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 13:14:35'),(77,1,'System Administrator','user.login','user',1,'admin','{\"role\": \"admin\", \"loginTime\": \"2025-07-03T13:31:12.871Z\"}','192.168.1.137','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 13:31:12'),(78,1,'System Administrator','case.view','case',7,'ООО «ART MEBEL STYLE»','{\"caseType\": \"litigation\", \"caseNumber\": \"44/2025-ХС\"}','192.168.1.137','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 13:32:22'),(79,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": null, \"opponentName\": \"ООО «ART MEBEL STYLE»\", \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.137','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 13:32:41'),(80,1,'System Administrator','case.view','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"caseNumber\": \"49/2025-Х\"}','192.168.1.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:07:49'),(81,1,'System Administrator','case.update','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"changes\": {\"founders\": [], \"case_type\": \"other\", \"directors\": [{\"name\": \"Chandra Satish\", \"pinfl\": \"\"}], \"client_inn\": \"310079845\", \"client_name\": \"ООО «AGIO HEALTHCARE INTERNATIONAL»\", \"description\": \"Анализ и правовая экспертиза договора на оказание рекламных услуг, а также внесение необходимых\\nправок в его положения в интересах Доверителя и в соответствии с требованиями законодательства\\nРеспублики Узбекистан.\", \"opponent_inn\": \"\", \"beneficiaries\": [], \"opponent_name\": \"\", \"lawyersAssigned\": [], \"related_companies\": []}, \"updatedFields\": [\"client_name\", \"client_inn\", \"opponent_name\", \"opponent_inn\", \"case_type\", \"description\", \"lawyersAssigned\", \"related_companies\", \"founders\", \"directors\", \"beneficiaries\"]}','192.168.1.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:09:57'),(82,1,'System Administrator','case.view','case',8,'ООО «AGIO HEALTHCARE INTERNATIONAL»','{\"caseType\": \"other\", \"caseNumber\": \"49/2025-Х\"}','192.168.1.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:09:57'),(83,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"310079845\", \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:10:22'),(84,1,'System Administrator','case.create','case',9,'ООО «Crypto Market»','{\"caseType\": \"contract\", \"clientInn\": \"310007768\", \"caseNumber\": \"51/2025-X\", \"clientName\": \"ООО «Crypto Market»\", \"opponentInn\": null, \"opponentName\": null, \"conflictLevel\": \"none\", \"lawyersAssigned\": []}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:31:49'),(85,1,'System Administrator','case.view','case',9,'ООО «Crypto Market»','{\"caseType\": \"contract\", \"caseNumber\": \"51/2025-X\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:31:57'),(86,1,'System Administrator','document.upload','document',14,'LSA_PraeLegal_Crypto Market_3 July 2025 (2).pdf','{\"caseId\": \"9\", \"caseName\": \"ООО «Crypto Market»\", \"fileName\": \"LSA_PraeLegal_Crypto Market_3 July 2025 (2).pdf\", \"fileSize\": 190233, \"mimeType\": \"application/pdf\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:32:14'),(87,1,'System Administrator','case.view','case',9,'ООО «Crypto Market»','{\"caseType\": \"contract\", \"caseNumber\": \"51/2025-X\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:32:14'),(88,1,'System Administrator','conflict.check','conflict_check',NULL,NULL,'{\"clientInn\": null, \"clientName\": null, \"searchType\": \"manual_search\", \"opponentInn\": \"310007768\", \"opponentName\": null, \"conflictLevel\": \"high\", \"conflictingCaseCount\": 1}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:35:32'),(89,1,'System Administrator','user.login','user',1,'admin','{\"role\": \"admin\", \"loginTime\": \"2025-07-03T14:37:24.775Z\"}','192.168.1.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-07-03 14:37:24');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_lawyers`
--

DROP TABLE IF EXISTS `case_lawyers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_lawyers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `lawyer_id` int NOT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `assigned_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_case_lawyer` (`case_id`,`lawyer_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_lawyer_id` (`lawyer_id`),
  KEY `idx_assigned_by` (`assigned_by`),
  CONSTRAINT `fk_case_lawyers_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_case_lawyers_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_case_lawyers_lawyer` FOREIGN KEY (`lawyer_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_lawyers`
--

LOCK TABLES `case_lawyers` WRITE;
/*!40000 ALTER TABLE `case_lawyers` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_lawyers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_number` varchar(100) DEFAULT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_inn` varchar(20) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `opponent_inn` varchar(20) DEFAULT NULL,
  `case_type` enum('litigation','contract','consultation','other') DEFAULT NULL,
  `description` text,
  `related_companies` json DEFAULT NULL,
  `founders` json DEFAULT NULL,
  `directors` json DEFAULT NULL,
  `beneficiaries` json DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `case_number` (`case_number`),
  KEY `created_by` (`created_by`),
  KEY `idx_inn` (`client_inn`,`opponent_inn`),
  FULLTEXT KEY `idx_client_search` (`client_name`,`opponent_name`),
  CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` VALUES (7,'44/2025-ХС','ООО «ART MEBEL STYLE»','304365452','АТБ «Бизнесни ривожлантириш банки»','','litigation','❖ Дача консультаций и разъяснений по правовым вопросам касательно договора № 4243511.1.1\nот 26.02.2025 года, заключенный между Доверителем и АТБ «Бизнесни ривожлантириш банки»;\n❖ Представление и защита прав и законных интересов Доверителя в судебном заседании,\nназначенном на 7 июля 2025 года, по экономическому делу № 4-1001-2504/65467 по исковому\nзаявлению АТБ «Бизнесни ривожлантириш банки» к Доверителю.','[]','[]','[{\"name\": \"UMAROV ABDULAHAD RAXMATJON O`G`LI\", \"pinfl\": \"\"}]','[]',1,'2025-07-03 12:11:55','2025-07-03 12:55:41'),(8,'49/2025-Х','ООО «AGIO HEALTHCARE INTERNATIONAL»','310079845','','','other','Анализ и правовая экспертиза договора на оказание рекламных услуг, а также внесение необходимых\nправок в его положения в интересах Доверителя и в соответствии с требованиями законодательства\nРеспублики Узбекистан.','[]','[]','[{\"name\": \"Chandra Satish\", \"pinfl\": \"\"}]','[]',1,'2025-07-03 12:15:51','2025-07-03 14:09:57'),(9,'51/2025-X','ООО «Crypto Market»','310007768',NULL,NULL,'contract','1.1. Доверитель поручает, а Адвокатская фирма принимает на себя обязанность оказывать Доверителю\nюридическую помощь в соответствии с законодательством Республики Узбекистан, а Доверитель обязуется\nпринять такую помощь и оплатить вознаграждение Адвокатской фирме в размере и в соответствии с порядком,\nопределенным настоящим Договором и его Приложениями.\n1.2. Адвокатская фирма оказывает юридическую помощь в соответствии с письменными поручениями\nДоверителя по форме, которую согласуют Стороны (далее – «Поручение»). Поручение подписывается обеими\nСторонами и может устанавливать объём, сроки выполнения и размер вознаграждения, порядок его выплаты и\nиные условия юридической помощи. Подписанные обеими Сторонами Поручения становятся Приложениями к\nнастоящему Договору и являются его неотъемлемой частью.\n1.3. Уполномоченный адвокат по данному Договору определяется Адвокатской фирмой по ее усмотрению.','[]','[]','[]','[]',1,'2025-07-03 14:31:49','2025-07-03 14:31:49');
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conflict_checks`
--

DROP TABLE IF EXISTS `conflict_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conflict_checks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int DEFAULT NULL,
  `conflict_level` enum('high','medium','low','none') DEFAULT NULL,
  `conflict_reason` text,
  `conflicting_cases` json DEFAULT NULL,
  `checked_by` int NOT NULL,
  `checked_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `checked_by` (`checked_by`),
  KEY `conflict_checks_ibfk_1` (`case_id`),
  CONSTRAINT `conflict_checks_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `conflict_checks_ibfk_2` FOREIGN KEY (`checked_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conflict_checks`
--

LOCK TABLES `conflict_checks` WRITE;
/*!40000 ALTER TABLE `conflict_checks` DISABLE KEYS */;
INSERT INTO `conflict_checks` VALUES (18,7,'none','','[]',1,'2025-07-03 12:11:55'),(19,8,'none','','[]',1,'2025-07-03 12:15:51'),(20,7,'none','','[]',1,'2025-07-03 12:55:41'),(21,8,'none','','[]',1,'2025-07-03 14:09:57'),(22,9,'none','','[]',1,'2025-07-03 14:31:49');
/*!40000 ALTER TABLE `conflict_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `case_id` (`case_id`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (12,7,'1751544733873-457575.pdf','Договор_юр_помощь_07.07.2025.pdf','uploads/ООО_«ART_MEBEL_STYLE_44_2025-ХС/1751544733873-457575.pdf',181622,'application/pdf',1,'2025-07-03 12:12:13'),(13,8,'1751544964170-315469083.pdf','Договор разовый_Amrita pharm 25062025.pdf','uploads/ООО_«AGIO_HEALTHCARE_INTERNATIONAL»_49_2025-Х/1751544964170-315469083.pdf',161922,'application/pdf',1,'2025-07-03 12:16:04'),(14,9,'1751553134432-21532814.pdf','LSA_PraeLegal_Crypto Market_3 July 2025 (2).pdf','uploads/ООО_«Crypto_Market»_51_2025-X/1751553134432-21532814.pdf',190233,'application/pdf',1,'2025-07-03 14:32:14');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_documents`
--

DROP TABLE IF EXISTS `entity_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `entity_type` enum('related_companies','founders','directors','beneficiaries') NOT NULL,
  `entity_index` int NOT NULL COMMENT 'Индекс элемента в JSON массиве',
  `entity_name` varchar(255) NOT NULL,
  `entity_inn` varchar(20) DEFAULT NULL COMMENT 'ИНН для компаний и учредителей',
  `entity_pinfl` varchar(14) DEFAULT NULL COMMENT 'ПИНФЛ для директоров',
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `case_id` (`case_id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_entity_lookup` (`case_id`,`entity_type`,`entity_index`),
  CONSTRAINT `entity_documents_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entity_documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Документы связанных с делом лиц (компании, учредители, директора, бенефициары)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_documents`
--

LOCK TABLES `entity_documents` WRITE;
/*!40000 ALTER TABLE `entity_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `role` enum('admin','user','viewer') DEFAULT 'user',
  `email` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `permissions` json DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'System Administrator','Administrator','admin','admin@conflictchecker.local','admin','$2b$10$tIxdz9x41lK3GSVV9g739.OcvR9zatty1HZJTllR15n/ZJHqbjsFa',1,'{\"edit\": true, \"create\": true, \"delete\": true, \"manageUsers\": 1}',NULL,'2025-07-01 10:10:55','2025-07-02 10:59:21'),(4,'Abdulkasimov Sherzod','Партнер','user','sherzod@praelegal.uz','Sherzod','$2b$10$Hba61EE/aZZq6k7mxG9jTOLOdUk1ECq8D1PNYHBDP10kFpTXEwWDi',1,'{\"edit\": true, \"create\": true, \"delete\": true, \"manageUsers\": true}',1,'2025-07-02 11:37:05','2025-07-02 11:37:05'),(5,'Axmatov Davranbek','Партнер','user','d.ahmatov@praelegal.uz','Davranbek','$2b$10$NmExW93utyI4y7vGc82oIuWLC2KkmVzR82ksICi3ufVTAmOdnp67K',1,'{\"edit\": true, \"create\": true, \"delete\": true, \"manageUsers\": true}',1,'2025-07-02 11:37:40','2025-07-02 11:37:40'),(6,'Kim Irina','Партнер','user','i.kim@praelegal.uz','Irina','$2b$10$3XXd0Zf6FI/J104PpoHYHuk.POOK/gjpOCHHWoppKaHdWxL039Yaq',1,'{\"edit\": true, \"create\": true, \"delete\": true, \"manageUsers\": true}',1,'2025-07-02 11:38:16','2025-07-02 11:38:16'),(7,'Ismatov Jahongir','Начальник корпоративного отдела','user','j.ismatov@praelegal.uz','Jahongir','$2b$10$pZrzYA9.C.BSAi7SSCu1vuDd8QU7569tzKKtM9HH460z7cbHyhEc6',0,'{\"edit\": false, \"create\": true, \"delete\": false, \"manageUsers\": false}',1,'2025-07-03 08:56:41','2025-07-03 13:14:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-03 19:39:17
